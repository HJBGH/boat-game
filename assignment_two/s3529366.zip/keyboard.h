#include "includes.h"
#include "boats.h" /*gets included as the keyboard will have to 
interact with boats*/
#include "island.h"
void keyboard(unsigned char, int, int);
void keyUp(unsigned char, int, int);
