#ifndef TERRAIN
#define TERRAIN
#define T_SEGMENTS 32

//float terrain_y[][];

//void calcTerrain( * float[][]); 
//this will have a function hard inside it
void drawTerrain(float);
#endif
