#include "includes.h"

void mouseMotion(int, int);
void mouseClicked(int, int, int, int);
